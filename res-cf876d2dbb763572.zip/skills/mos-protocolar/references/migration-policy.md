# Resoluciones explícitas de migración — 0.1.1

Estas resoluciones son decisiones nuevas de implementación; no se atribuyen al prompt perdido. Conservar el contenido del ZIP como referencia, con normalización de codificación. Aplicar exclusivamente estas sustituciones al contenido de origen. Cualquier conflicto adicional exige aclaración.

| Punto | Conflicto de origen | Regla operativa de esta versión |
| --- | --- | --- |
| Inicio | Launcher inicia; Workflows asigna un plan a `//marketing-os` | `//marketing-os` inicia. Una tarea acompañante se resuelve por separado. Sin tarea, no ejecutar plan. |
| Plan completo | Core/Router terminan en calendario; Workflows añade rendimiento y optimización | `//full-plan` termina en calendario. Rendimiento y optimización requieren datos observados y solicitudes independientes. |
| Rendimiento | Registry exige calendario; protocolo lo considera opcional | Calendario opcional; datos reales de ejecución obligatorios. Objetivos necesarios para juzgar su cumplimiento. |
| Dependencias | Registry simplifica Topic y Content Plan | Exigir todas las dependencias explícitas del protocolo especializado, reflejadas en runtime-registry.json. |
| Operación individual | Algunos workflows encadenan protocolos anteriores | Un comando individual ejecuta solo su protocolo. Si faltan dependencias, solicitar entrada o una operación previa. Solo un flujo autorizado encadena etapas. |
| Comandos reservados | Manifest/Router los enumeran como disponibles; Registry los reserva | Permanecen reservados y no ejecutables. |
| Referencias futuras | Se citan MKT-TREND, MKT-NEWS, MKT-OPPORTUNITY y MKT-GROWTH sin sus archivos | No registrarlos como protocolos ejecutables. |
| Registros de arranque | Los documentos describen registros y estados | Son operaciones lógicas del modelo, no procesos independientes. No inventar trazas ni afirmar validaciones no realizadas. |
| Rol y CIP | Estándar pide percepción de experto; CIP menciona simulación humana | No adoptar personaje humano. Conservar claridad, ritmo y legibilidad sin identidad ficticia. |
| Resultado y estado | Output System limita respuesta a tres preguntas de estado | Ese límite aplica a mensajes de estado y fallos; no elimina secciones del resultado especializado. |
| Contexto | Se prescribe destrucción al cerrar sesión y se ofrece restart | No prometer borrado real ni control del ciclo de vida del host. Restart reinicia solo el estado lógico de MOS. |
| Exportaciones | Se declaran formatos y compatibilidad con servicios | Generación sujeta a herramientas disponibles. No implica integraciones, servidor propio ni publicación externa. |
| Recomendaciones | Estándar común pide recomendaciones; Performance limita recomendaciones | Prevalece el límite especializado. Performance entrega hallazgos; los cambios corresponden a Optimizer. |

El contrato operativo tiene prioridad sobre las personificaciones y afirmaciones de infraestructura de origen. El registro operativo de este complemento es la fuente ejecutable por instrucciones para comandos, alias, flujos y dependencias; el registro original se conserva para trazabilidad.

## Resoluciones de representación — 0.1.1

Estas decisiones corrigen la integración de salida de 0.1.0; no se atribuyen al prompt perdido.

- Aplicar Deliverable Translator a resultados especializados tanto en chat como en archivos. Su estructura es independiente del formato; la generación de archivos sigue siendo condicional.
- Interpretar los elementos de `output_sections` como cobertura semántica. No convertirlos automáticamente en títulos ni suprimir contenido obligatorio para cumplir CIP.
- Aplicar el contrato de representación y revisar HCEP, CRL y HRR en cada salida. Conservar las decisiones y los límites de los protocolos especializados.
- Los objetos son datos estructurados; las vistas interactivas dependen de capacidades reales del host. No prometer que el paquete añade una interfaz propia.

## Límites de implementación

El paquete es de habilidades y referencias. No contiene herramientas MCP, base de datos ni servicio que imponga transiciones. El seguimiento del contrato depende del modelo. No afirmar equivalencia garantizada con un GPT personalizado ni cumplimiento determinista. Una futura versión con controles por código requiere implementación y pruebas adicionales.

