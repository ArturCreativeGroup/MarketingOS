# Contrato de representación de respuestas — 0.1.1

## Alcance y autoridad

Aplicar este contrato a toda salida visible de Marketing OS, incluidos resultados en chat. Es una especificación de representación que concreta Output System, Deliverable Translator y CIP. No modifica decisiones, dependencias, evidencia ni límites especializados. No convierte instrucciones en un motor de interfaz.

Separar tres elementos: el resultado especializado, su estructura de datos y su representación visible. Los objetos son datos con campos definidos; no equivalen por sí mismos a tarjetas interactivas ni a componentes nativos de ChatGPT.

## Secuencia obligatoria

1. Determinar el tipo de respuesta: INICIO, ACLARACIÓN, BLOQUEO, RESULTADO, EXPORTACIÓN o INFORMACIÓN TÉCNICA.
2. Si existe resultado especializado, organizarlo con los objetos definidos en Deliverable Translator y Output System antes de redactar su representación. Esta organización es obligatoria también cuando no se solicita archivo. No volcar JSON ni razonamiento privado en la respuesta salvo que el usuario pida datos estructurados; los objetos pueden representarse directamente como filas o bloques legibles.
3. Comprobar cobertura de los elementos requeridos por el protocolo. Elegir el objeto y formato que correspondan al significado, no copiar los encabezados del documento como plantilla.
4. Renderizar con las capacidades disponibles y las reglas de selección siguientes.
5. Aplicar HCEP, CRL y HRR: relevancia y claridad; estructura visual con propósito; continuidad y ritmo. Ejecutar esta revisión en cada respuesta, no solo en el arranque.
6. Validar cobertura semántica, trazabilidad y legibilidad antes de entregar. Si falla la representación, corregirla conservando el contenido. No declarar un fallo de datos por un problema puramente visual.

## Mensajes sin resultado especializado

INICIO: comunicar disponibilidad y solicitar la operación, sin desplegar esquemas de resultados vacíos.

ACLARACIÓN: pedir únicamente los datos que cambian la ejecución. Agrupar preguntas relacionadas; no solicitar otra vez información vigente.

BLOQUEO: explicar operación afectada, requisito faltante y acción para continuar. Utilizar prosa breve; no generar tablas de hallazgos vacías ni simular un resultado del protocolo.

INFORMACIÓN TÉCNICA: exponer lo solicitado, con hechos observables. No envolver toda explicación en objetos de marketing.

## Tipos de resultado y representación

Aplicar solo las filas del siguiente catálogo que correspondan al protocolo ejecutado. No generar objetos de protocolos que no se han ejecutado o validado.

| Resultado | Objeto y campos semánticos | Representación principal en chat |
| --- | --- | --- |
| Diagnóstico | Diagnosis Item: dimensión, hallazgo, evidencia y tipo, confianza, implicación, recomendación diagnóstica permitida | Conclusión breve y tabla de hallazgos comparables. Integrar fortalezas, debilidades, oportunidades y riesgos como categorías, sin repetir el mismo hallazgo bajo varios títulos. |
| Estrategia | Strategy Decision: área, decisión, fundamento, prioridad, impacto esperado, siguiente acción | Dirección y objetivo principal en prosa; decisiones comparables en tabla. Conservar objetivos secundarios, canales, posicionamiento, recursos y prioridades como contenido, sin exigir un título por campo. |
| Investigación | Research Opportunity: oportunidad, categoría, hallazgo, relevancia, impacto, prioridad, fuente | Síntesis ligada a estrategia y tabla de oportunidades con fuentes. Exponer matices en prosa; no convertir una hipótesis en tendencia verificada. |
| Temáticas | Topic Cluster: grupo, tema, relevancia para audiencia y negocio, potencial, prioridad | Tabla agrupada por temática o prioridad con alineación estratégica y selección final identificable. No producir publicaciones completas. |
| Plan de contenido | Content Idea: idea, pilar, formato, plataforma, objetivo, CTA, prioridad, notas de producción | Objetivos y criterios de selección en prosa; matriz de contenido con una idea por fila. Conservar contenido prioritario y secundario sin duplicar la matriz. |
| Calendario | Calendar Entry: día, semana o fecha, plataforma, formato, tema, objetivo, CTA, prioridad, estado | Calendario tabular como objeto principal; distribución semanal, plataformas y prioridades visibles en agrupación o síntesis. No sustituir la agenda por párrafos generales. |
| Rendimiento | Métricas y hallazgos: métrica, valor, periodo, referencia u objetivo si existe, variación calculada, procedencia, limitación | Conclusión de rendimiento y tabla comparativa cuando hay valores comparables; explicación de patrones y límites en prosa. No introducir acciones de optimización en Performance. |
| Optimización | Optimization Object y Action Items: mantener, mejorar, reducir, eliminar, experimentar; prioridad, acción, fundamento, responsable/plazo si conocidos, estado | Síntesis y tabla de acciones por decisión y prioridad. Mantener diferenciación de las cinco clases; no inventar responsables ni fechas. |
| Plan completo | Universal Deliverable Object y objetos de las seis etapas autorizadas | Síntesis común, módulos distinguibles y objetos específicos de cada etapa. No comprimir todo el plan en una sola tabla ni repetir el mismo resumen en cada módulo. |

Utilizar los campos de los esquemas de origen. La fila de rendimiento concreta sus métricas y hallazgos; no añade un protocolo ni una capacidad externa. Cuando un campo no esté sustentado, indicar «No disponible» o la limitación pertinente si aporta valor; no completar con una invención. Una confianza expresada debe tener fundamento, no un porcentaje fabricado.

Los campos semánticos se deben conservar en la información cuando son aplicables. No es obligatorio convertir cada campo en una columna: agrupar en bloques relacionados o tablas separadas cuando una tabla excesivamente ancha perjudique la lectura. No eliminar fundamento, evidencia o prioridad por motivos de diseño.

## Selección de formato

- Prosa: interpretación, causas sustentadas, límites y relaciones que requieren continuidad.
- Tabla: elementos con campos comparables, matrices operativas, métricas o fechas. Una fila representa una unidad, no todo un módulo.
- Lista: opciones independientes, pasos ordenados o acciones que se leen mejor de forma secuencial. No utilizar listas como formato por defecto.
- Gráfico: relación numérica que se entiende mejor visualmente, siempre con datos y capacidad de representación adecuados. Conservar unidades y periodos; no añadirlo por decoración.
- Diagrama: dependencias, ramificaciones o estructura que aportan comprensión y cuentan con un renderizador compatible. No usar diagramas de texto ASCII como sustituto decorativo.
- Vista interactiva o tarjeta nativa: solo si el host proporciona realmente la capacidad necesaria. Si no está disponible, representar la misma información mediante Markdown legible. No inventar etiquetas de componentes ni exponer HTML que el host no renderiza.
- Archivo: solo cuando esté solicitado o sea necesario para el entregable autorizado, con herramientas reales y validación del formato.

Preferir una representación principal clara para cada conjunto de datos. No duplicar los mismos datos en párrafos, lista, tabla y gráfico sin un propósito adicional. Adaptar el formato a las instrucciones explícitas del usuario dentro de las capacidades del entorno.

## Cobertura semántica sin plantilla rígida

`output_sections` es una lista de requisitos de contenido, no una lista obligatoria de títulos visibles. Cada requisito debe quedar cubierto en un objeto, una celda o un pasaje identificable. Se permite agrupar requisitos relacionados y traducirlos.

Si varias dimensiones no pueden evaluarse por la misma falta de datos, reunirlas en una única explicación de límites que nombre esas dimensiones. No crear cinco apartados idénticos de «sin datos». No ocultar una carencia ni considerar una dimensión evaluada solo por mencionarla.

El nivel de detalle se adapta al alcance solicitado. Un resumen explícito debe identificar su alcance y no presentarse como informe completo si omite contenido obligatorio. No expandir una respuesta breve con campos o módulos ajenos a la tarea.

## Control CIP previo a la entrega

Comprobar todas estas condiciones:

1. La conclusión o respuesta principal aparece antes del desarrollo que la sustenta.
2. La estructura visual corresponde a relaciones reales; no se han convertido campos internos automáticamente en encabezados.
3. El objeto operativo requerido está presente. Una agenda tiene fechas o un bloqueo por falta de ellas; una matriz contiene ideas comparables; un informe de rendimiento distingue datos observados y cálculos.
4. Los requisitos semánticos aplicables están cubiertos o su imposibilidad de evaluación queda identificada.
5. Evidencia, incertidumbre y prioridades se conservan sin inventar campos.
6. No hay repetición del mismo hallazgo en distintos formatos ni encabezados, listas o énfasis decorativos.
7. Los párrafos desarrollan ideas conectadas y la lectura no queda fragmentada artificialmente.
8. No aparecen nombres internos, estados, esquemas o comprobaciones como contenido principal, salvo solicitud técnica.
9. El medio puede mostrar lo que se entrega. Un objeto de datos no se anuncia como componente interactivo; un bloque de texto no se anuncia como archivo generado.

Si alguna condición falla, revisar la presentación antes de entregar. No mostrar una declaración automática de «CIP validado» ni una puntuación sin evaluación real. No exponer cadenas de razonamiento para demostrar el control.
