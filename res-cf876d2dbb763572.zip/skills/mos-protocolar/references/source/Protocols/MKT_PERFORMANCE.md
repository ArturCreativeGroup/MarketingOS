# MARKETING OS

## MKT-PERFORMANCE

Version: 1.0 Experimental

Category: Optimization Protocol

Protocol ID: MKT-PERFORMANCE

---

# 1. PURPOSE

MKT-PERFORMANCE existe para evaluar los resultados obtenidos tras la ejecución de una estrategia de contenido.

Su función es transformar métricas en conocimiento accionable.

No optimiza.

No modifica estrategias.

No genera nuevas recomendaciones.

Su responsabilidad es analizar resultados.

---

# 2. CORE QUESTION

Este protocolo responde una única pregunta:

¿Qué ocurrió realmente?

---

# 3. ACTIVATION

Puede activarse mediante:

```text
//performance
```

o indirectamente desde:

```text
//optimize

//marketing-os
```

---

# 4. DEPENDENCIES

Idealmente utiliza:

```text
MKT-CALENDAR
```

aunque puede funcionar sin él.

---

# 5. INPUTS

Puede analizar:

---

## Redes Sociales

TikTok

Instagram

LinkedIn

YouTube

X

Facebook

---

## Métricas

Visualizaciones

Impresiones

Alcance

Guardados

Compartidos

Comentarios

Seguidores

Conversiones

---

## Calendarios

Planes ejecutados.

---

## Estrategias

Estrategias previas.

---

## Capturas

Paneles analíticos.

---

## Informes

Documentos de rendimiento.

---

# 6. PERFORMANCE DIMENSIONS

El protocolo analiza siete dimensiones.

---

## D1 — Alcance

Evalúa:

* visibilidad
* distribución
* exposición

---

## D2 — Interacción

Evalúa:

* comentarios
* compartidos
* guardados
* participación

---

## D3 — Crecimiento

Evalúa:

* seguidores
* comunidad
* evolución

---

## D4 — Consistencia

Evalúa:

* frecuencia
* cumplimiento
* continuidad

---

## D5 — Rendimiento de Temáticas

Evalúa:

* temas fuertes
* temas débiles

---

## D6 — Rendimiento de Formatos

Evalúa:

* vídeo
* carrusel
* artículo
* post

---

## D7 — Rendimiento de Plataformas

Evalúa:

* plataformas fuertes
* plataformas débiles

---

# 7. ANALYSIS PRIORITY

La evaluación debe seguir este orden.

```text
Objetivos
↓
Resultados
↓
Patrones
↓
Conclusiones
```

---

Nunca al revés.

---

# 8. EVIDENCE HIERARCHY

Toda conclusión debe basarse en evidencia.

---

## Nivel 1

Datos reales.

---

## Nivel 2

Capturas.

---

## Nivel 3

Informes.

---

## Nivel 4

Declaraciones del usuario.

---

## Nivel 5

Inferencias.

---

# 9. PATTERN DETECTION

El protocolo debe detectar:

---

## Ganadores

Qué funciona.

---

## Perdedores

Qué no funciona.

---

## Repeticiones

Patrones consistentes.

---

## Anomalías

Resultados inesperados.

---

# 10. OUTPUT STRUCTURE

La salida oficial debe contener:

---

## Executive Summary

Resumen.

---

## Reach Analysis

Análisis de alcance.

---

## Engagement Analysis

Análisis de interacción.

---

## Growth Analysis

Análisis de crecimiento.

---

## Topic Analysis

Análisis de temáticas.

---

## Format Analysis

Análisis de formatos.

---

## Platform Analysis

Análisis de plataformas.

---

## Key Findings

Hallazgos principales.

---

## Performance Conclusion

Conclusión final.

---

# 11. OUTPUT RESTRICTIONS

El protocolo NO debe:

* modificar estrategias
* generar calendarios
* optimizar planes
* recomendar cambios estructurales

---

Estas tareas pertenecen a:

```text
MKT-OPTIMIZER
```

---

# 12. CHILD PROTOCOLS

Puede alimentar:

```text
MKT-OPTIMIZER
```

---

# 13. SUCCESS CRITERIA

El protocolo se considera exitoso cuando identifica claramente:

---

## Qué funciona

---

## Qué no funciona

---

## Qué se repite

---

## Qué merece más atención

---

## Qué debería abandonarse

---

# 14. CIP COMPLIANCE

---

## HCEP

Priorizar hallazgos accionables.

---

## CRL

Agrupar métricas por significado.

---

## HRR

Mantener lectura fluida.

---

# 15. FINAL OUTPUT

La salida final debe responder:

```text
¿Qué ocurrió realmente?

¿Qué funcionó?

¿Qué no funcionó?

¿Qué patrones existen?

¿Qué merece atención?
```

---

END OF PROTOCOL
