# MARKETING OS

## MKT-OPTIMIZER

Version: 1.0 Experimental

Category: Optimization Protocol

Protocol ID: MKT-OPTIMIZER

---

# 1. PURPOSE

MKT-OPTIMIZER existe para transformar resultados observados en acciones de mejora.

Su función es identificar ajustes que incrementen la probabilidad de alcanzar los objetivos definidos.

No analiza métricas.

No genera diagnósticos.

No evalúa rendimiento.

Su responsabilidad es decidir qué debe cambiar.

---

# 2. CORE QUESTION

Este protocolo responde una única pregunta:

¿Qué deberíamos cambiar?

---

# 3. ACTIVATION

Puede activarse mediante:

```text
//optimize
```

o indirectamente desde:

```text
//marketing-os
```

---

# 4. DEPENDENCIES

Requiere:

```text
MKT-PERFORMANCE
```

---

Idealmente también utiliza:

```text
MKT-STRATEGY

MKT-CALENDAR
```

---

Sin análisis de rendimiento:

```text
No existen datos suficientes para optimizar.
```

---

# 5. INPUTS

Puede utilizar:

---

## Performance Reports

Resultados de:

```text
MKT-PERFORMANCE
```

---

## Estrategias

Resultados de:

```text
MKT-STRATEGY
```

---

## Calendarios

Resultados de:

```text
MKT-CALENDAR
```

---

## Planes de Contenido

Resultados de:

```text
MKT-CONTENT-PLAN
```

---

## Contexto

Información disponible en la sesión.

---

# 6. OPTIMIZATION DIMENSIONS

El protocolo optimiza siete dimensiones.

---

## D1 — Objetivos

Evalúa:

* alineación
* claridad
* viabilidad

---

## D2 — Plataformas

Evalúa:

* inversión de esfuerzo
* distribución de recursos
* rendimiento relativo

---

## D3 — Temáticas

Evalúa:

* relevancia
* rendimiento
* potencial futuro

---

## D4 — Formatos

Evalúa:

* eficiencia
* aceptación
* repetibilidad

---

## D5 — Frecuencia

Evalúa:

* sostenibilidad
* impacto
* consistencia

---

## D6 — Recursos

Evalúa:

* tiempo disponible
* esfuerzo requerido
* retorno esperado

---

## D7 — Prioridades

Evalúa:

* qué reforzar
* qué reducir
* qué eliminar

---

# 7. OPTIMIZATION LOGIC

Toda recomendación debe seguir el siguiente orden.

```text
Objetivos
↓
Resultados
↓
Patrones
↓
Cambios
↓
Prioridades
```

---

Nunca:

```text
Cambios
↓
Resultados
```

---

# 8. OPTIMIZATION TYPES

---

## Reinforce

Reforzar.

---

Aplicar cuando algo funciona consistentemente.

---

## Improve

Mejorar.

---

Aplicar cuando existe potencial no aprovechado.

---

## Reduce

Reducir.

---

Aplicar cuando el retorno es bajo.

---

## Remove

Eliminar.

---

Aplicar cuando el coste supera el beneficio.

---

## Experiment

Experimentar.

---

Aplicar cuando no existe evidencia suficiente.

---

# 9. RECOMMENDATION SYSTEM

Toda recomendación debe incluir:

---

## Acción

Qué hacer.

---

## Justificación

Por qué hacerlo.

---

## Impacto Esperado

Qué se espera conseguir.

---

## Prioridad

Nivel de importancia.

---

# 10. PRIORITY SYSTEM

---

## O1

Optimización crítica.

---

## O2

Optimización alta.

---

## O3

Optimización media.

---

## O4

Optimización baja.

---

## O5

Opcional.

---

# 11. OUTPUT STRUCTURE

La salida oficial debe contener:

---

## Executive Summary

Resumen.

---

## What Works

Qué debe mantenerse.

---

## What Needs Improvement

Qué debe mejorarse.

---

## What Should Be Reduced

Qué debe reducirse.

---

## What Should Be Removed

Qué debe eliminarse.

---

## New Experiments

Nuevas pruebas recomendadas.

---

## Optimization Roadmap

Hoja de ruta.

---

## Final Recommendations

Recomendaciones finales.

---

# 12. OUTPUT RESTRICTIONS

El protocolo NO debe:

* modificar objetivos automáticamente
* generar contenido
* generar copies
* generar diseños
* generar campañas completas

---

Estas acciones requieren intervención de protocolos posteriores o del usuario.

---

# 13. WORKFLOW INTEGRATION

Parent Protocol:

```text
MKT-PERFORMANCE
```

---

Child Protocols:

Ninguno.

---

Este protocolo representa el cierre del ciclo operativo de Marketing OS.

---

# 14. SUCCESS CRITERIA

El protocolo se considera exitoso cuando:

---

El usuario comprende:

* qué mantener
* qué mejorar
* qué reducir
* qué eliminar
* qué experimentar

---

# 15. CIP COMPLIANCE

---

## HCEP

Eliminar recomendaciones sin impacto.

---

## CRL

Agrupar optimizaciones por prioridad.

---

## HRR

Mantener continuidad lógica.

---

# 16. FINAL OUTPUT

La salida final debe responder:

```text
¿Qué debemos mantener?

¿Qué debemos mejorar?

¿Qué debemos reducir?

¿Qué debemos eliminar?

¿Qué deberíamos experimentar después?
```

---

# 17. CYCLE COMPLETION

MKT-OPTIMIZER completa el ciclo principal de Marketing OS.

```text
Diagnóstico
↓
Estrategia
↓
Investigación
↓
Temáticas
↓
Plan de Contenido
↓
Calendario
↓
Rendimiento
↓
Optimización
↓
Nuevo Diagnóstico
```

---

END OF PROTOCOL
