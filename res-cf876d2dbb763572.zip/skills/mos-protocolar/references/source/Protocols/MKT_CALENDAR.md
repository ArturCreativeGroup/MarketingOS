# MARKETING OS

## MKT-CALENDAR

Version: 1.0 Experimental

Category: Planning Protocol

Protocol ID: MKT-CALENDAR

---

# 1. PURPOSE

MKT-CALENDAR existe para transformar un plan de contenido en una secuencia temporal ejecutable.

Su función es organizar la ejecución.

No decide qué contenido crear.

No genera contenido.

No genera copies.

Su responsabilidad es determinar cuándo debe ejecutarse cada acción.

---

# 2. CORE QUESTION

Este protocolo responde una única pregunta:

¿Cuándo debemos ejecutar cada contenido?

---

# 3. ACTIVATION

Puede activarse mediante:

```text
//calendar
```

o indirectamente desde:

```text
//content-plan

//full-plan

//marketing-os
```

---

# 4. DEPENDENCIES

Requiere:

```text
MKT-CONTENT-PLAN
```

---

Sin plan de contenido:

```text
No existe contenido planificado para calendarizar.
```

---

# 5. INPUTS

Puede utilizar:

---

## Content Plan

Resultado generado por:

```text
MKT-CONTENT-PLAN
```

---

## Objetivos

Resultado generado por:

```text
MKT-STRATEGY
```

---

## Contexto

Información de la sesión activa.

---

## Restricciones

Disponibilidad

Frecuencia

Tiempo

Recursos

Equipo

---

# 6. CALENDAR DIMENSIONS

El protocolo organiza la planificación mediante seis dimensiones.

---

## D1 — Fecha

Cuándo se ejecuta.

---

## D2 — Plataforma

Dónde se publica.

---

## D3 — Objetivo

Qué pretende lograr.

---

## D4 — Prioridad

Nivel de importancia.

---

## D5 — Categoría

Tipo de contenido.

---

## D6 — Estado

Situación actual.

---

Ejemplos:

```text
Pendiente

En Producción

Programado

Publicado

Analizado
```

---

# 7. CALENDAR MODES

El protocolo puede generar distintos horizontes temporales.

---

## 7 Días

Plan semanal.

---

## 30 Días

Plan mensual.

---

## 60 Días

Plan bimensual.

---

## 90 Días

Plan trimestral.

---

# 8. DISTRIBUTION SYSTEM

El calendario debe distribuir contenido de forma equilibrada.

---

## Regla 01

Evitar concentración temática.

---

## Regla 02

Evitar repetición consecutiva.

---

## Regla 03

Mantener variedad estratégica.

---

## Regla 04

Priorizar contenido P1 antes que contenido P2.

---

## Regla 05

Priorizar contenido P2 antes que contenido P3.

---

# 9. WORKLOAD BALANCER

El protocolo debe considerar:

---

## Capacidad Real

¿Qué puede producir el usuario?

---

## Recursos Disponibles

¿Cuánto tiempo tiene?

---

## Frecuencia Recomendada

¿Qué frecuencia es sostenible?

---

La sostenibilidad tiene prioridad sobre la cantidad.

---

# 10. CALENDAR STRUCTURE

Cada entrada debe contener:

```text
Fecha

Plataforma

Temática

Categoría

Objetivo

Prioridad

Estado
```

---

Ejemplo:

```text
Fecha:
12/07/2026

Plataforma:
LinkedIn

Temática:
IA Aplicada

Categoría:
Caso Real

Objetivo:
Autoridad

Prioridad:
P1

Estado:
Pendiente
```

---

# 11. CALENDAR TYPES

---

## Editorial Calendar

Contenido.

---

## Campaign Calendar

Campañas.

---

## Launch Calendar

Lanzamientos.

---

## Mixed Calendar

Combinado.

---

# 12. OUTPUT STRUCTURE

La salida oficial debe contener:

---

## Executive Summary

Resumen.

---

## Calendar Overview

Vista general.

---

## Weekly Distribution

Distribución semanal.

---

## Platform Allocation

Distribución por plataforma.

---

## Priority Allocation

Distribución por prioridad.

---

## Calendar Table

Calendario principal.

---

# 13. EXPORT COMPATIBILITY

El protocolo debe generar estructuras compatibles con:

```text
Excel

CSV

Google Sheets

Notion

Airtable
```

---

# 14. OUTPUT RESTRICTIONS

El protocolo NO debe:

* generar copies
* generar publicaciones completas
* generar diseños
* generar vídeos

---

Estas funciones pertenecen a herramientas externas.

---

# 15. CHILD PROTOCOLS

Puede alimentar:

```text
MKT-PERFORMANCE

MKT-OPTIMIZER
```

---

# 16. SUCCESS CRITERIA

El protocolo se considera exitoso cuando:

---

El usuario comprende:

* qué debe publicar
* cuándo debe publicarlo
* dónde debe publicarlo
* qué debe priorizar

---

# 17. CIP COMPLIANCE

---

## HCEP

Eliminar complejidad innecesaria.

---

## CRL

Presentar calendarios de forma escaneable.

---

## HRR

Mantener continuidad visual.

---

# 18. FINAL OUTPUT

La salida final debe responder:

```text
¿Cuándo debemos ejecutar cada contenido?

¿Qué contenido tiene prioridad?

¿Cómo distribuimos el esfuerzo?

¿Qué frecuencia es sostenible?

¿Cuál es el plan operativo?
```

---

END OF PROTOCOL
