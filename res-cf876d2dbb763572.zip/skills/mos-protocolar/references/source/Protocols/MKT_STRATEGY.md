# MARKETING OS

## MKT-STRATEGY

Version: 1.0 Experimental

Category: Strategy Protocol

Protocol ID: MKT-STRATEGY

---

# 1. PURPOSE

MKT-STRATEGY existe para transformar un diagnóstico en una dirección estratégica.

Su objetivo no es generar contenido.

Su objetivo no es construir calendarios.

Su objetivo es determinar qué debe hacerse y qué debe ignorarse.

---

# 2. CORE QUESTION

Este protocolo responde una única pregunta:

¿Hacia dónde debemos dirigir nuestros esfuerzos?

---

# 3. ACTIVATION

Puede activarse mediante:

```text
//strategy
```

o mediante activación indirecta desde:

```text
//full-plan

//marketing-os
```

---

# 4. DEPENDENCIES

Requiere:

```text
MKT-DIAGNOSIS
```

---

Sin diagnóstico previo el protocolo debe indicar:

```text
No existe suficiente contexto para generar una estrategia confiable.
```

---

# 5. INPUTS

Puede utilizar:

---

## Diagnósticos

Resultados de MKT-DIAGNOSIS.

---

## Objetivos

Objetivos definidos por el usuario.

---

## Plataformas

Canales utilizados actualmente.

---

## Historial

Información obtenida durante la sesión.

---

## Restricciones

Tiempo

Recursos

Presupuesto

Equipo

Conocimientos

---

# 6. STRATEGIC DIMENSIONS

El protocolo analiza cinco dimensiones.

---

## D1 — Objetivo Principal

Determina:

¿Qué resultado es prioritario?

---

Ejemplos:

* conseguir clientes
* generar autoridad
* aumentar alcance
* validar producto
* construir comunidad

---

Debe existir únicamente un objetivo principal.

---

## D2 — Objetivos Secundarios

Determina:

¿Qué resultados apoyan el objetivo principal?

---

Ejemplo:

Objetivo principal:

```text
Conseguir clientes
```

Objetivos secundarios:

```text
Construir autoridad

Aumentar visibilidad

Generar confianza
```

---

## D3 — Canales Prioritarios

Determina:

¿Dónde debe concentrarse el esfuerzo?

---

No todas las plataformas tienen la misma prioridad.

---

Debe identificar:

### Canales principales

---

### Canales secundarios

---

### Canales prescindibles

---

# D4 — Posicionamiento

Determina:

¿Qué debe representar la marca?

---

Evalúa:

* diferenciación
* propuesta de valor
* percepción

---

# D5 — Asignación de Recursos

Determina:

¿Dónde deben invertirse tiempo y energía?

---

Ejemplos:

* contenido
* networking
* producto
* investigación
* comunidad

---

# 7. DECISION LOGIC

La estrategia debe construirse respetando el siguiente orden:

```text
Objetivo

↓

Posicionamiento

↓

Canales

↓

Recursos

↓

Acciones
```

---

Nunca al revés.

---

# 8. PRIORITY SYSTEM

El protocolo debe clasificar todas las acciones.

---

## P1

Prioridad crítica.

---

## P2

Prioridad alta.

---

## P3

Prioridad media.

---

## P4

Prioridad baja.

---

## P5

No recomendado.

---

# 9. STRATEGIC FILTER

Toda recomendación debe superar tres filtros.

---

## Relevancia

¿Contribuye al objetivo?

---

## Viabilidad

¿Puede ejecutarse?

---

## Impacto

¿Tiene potencial real?

---

Si falla cualquiera de los tres filtros:

La acción debe descartarse.

---

# 10. OUTPUT STRUCTURE

La salida oficial debe contener:

---

## Strategic Summary

Resumen estratégico.

---

## Primary Objective

Objetivo principal.

---

## Secondary Objectives

Objetivos secundarios.

---

## Channel Priorities

Canales priorizados.

---

## Positioning Recommendation

Posicionamiento recomendado.

---

## Resource Allocation

Distribución de recursos.

---

## Strategic Priorities

Prioridades estratégicas.

---

## Recommended Direction

Dirección recomendada.

---

# 11. OUTPUT RESTRICTIONS

El protocolo NO debe:

* generar publicaciones
* generar calendarios
* generar campañas completas
* generar copies
* generar diseños

---

Estas tareas pertenecen a protocolos posteriores.

---

# 12. CHILD PROTOCOLS

Puede alimentar:

```text
MKT-TREND

MKT-NEWS

MKT-OPPORTUNITY

MKT-TOPIC

MKT-CONTENT-PLAN

MKT-CALENDAR
```

---

# 13. SUCCESS CRITERIA

El protocolo se considera exitoso cuando el usuario comprende:

---

## Objetivo principal

Qué busca conseguir.

---

## Prioridades

Qué debe hacer primero.

---

## Enfoque

Dónde concentrar recursos.

---

## Descartes

Qué debe ignorar.

---

# 14. CIP COMPLIANCE

---

## HCEP

Eliminar recomendaciones irrelevantes.

---

## CRL

Presentar prioridades claramente.

---

## HRR

Mantener flujo lógico y natural.

---

# 15. FINAL OUTPUT

La salida final debe responder:

```text
¿Cuál es nuestro objetivo principal?

¿Qué debemos priorizar?

¿Qué debemos ignorar?

¿Dónde debemos invertir nuestros recursos?

¿Cuál es la dirección recomendada?
```

---

END OF PROTOCOL
