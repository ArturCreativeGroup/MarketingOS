# MARKETING OS

## MKT-TOPIC

Version: 1.0 Experimental

Category: Research Protocol

Protocol ID: MKT-TOPIC

---

# 1. PURPOSE

MKT-TOPIC existe para transformar investigación estratégica en temáticas accionables.

Su función es convertir:

* tendencias
* oportunidades
* problemas
* casos reales
* actualidad

en temas compatibles con la estrategia definida.

---

# 2. CORE QUESTION

Este protocolo responde una única pregunta:

¿Qué temas deberíamos abordar?

---

# 3. ACTIVATION

Puede activarse mediante:

```text
//topics
```

o indirectamente desde:

```text
//content-plan

//full-plan

//marketing-os
```

---

# 4. DEPENDENCIES

Requiere:

```text
MKT-STRATEGY

MKT-RESEARCH
```

---

Sin estrategia previa:

```text
No existe una dirección estratégica definida.
```

---

Sin investigación previa:

```text
No existen oportunidades suficientemente analizadas.
```

---

# 5. INPUTS

Puede utilizar:

---

## Estrategia

Resultado generado por:

```text
MKT-STRATEGY
```

---

## Investigación

Resultado generado por:

```text
MKT-RESEARCH
```

---

## Diagnóstico

Resultado generado por:

```text
MKT-DIAGNOSIS
```

---

## Contexto

Información disponible en la sesión.

---

# 6. TOPIC DIMENSIONS

El protocolo genera temáticas utilizando seis dimensiones.

---

## D1 — Problemas

Temas construidos alrededor de problemas.

---

Ejemplo:

```text
Errores comunes usando IA

Por qué tus publicaciones no generan resultados
```

---

## D2 — Soluciones

Temas construidos alrededor de soluciones.

---

Ejemplo:

```text
Cómo crear un sistema de contenido

Cómo reutilizar contenido correctamente
```

---

## D3 — Casos Reales

Temas construidos alrededor de experiencias.

---

Ejemplo:

```text
Cómo desarrollé una herramienta usando IA

Lo que aprendí creando un CRM
```

---

## D4 — Tendencias

Temas construidos alrededor de actualidad.

---

Ejemplo:

```text
La nueva actualización de ChatGPT

Cambios recientes en IA generativa
```

---

## D5 — Oportunidades

Temas construidos alrededor de oportunidades detectadas.

---

Ejemplo:

```text
Herramientas poco conocidas

Mercados emergentes
```

---

## D6 — Educación

Temas construidos alrededor de conocimiento.

---

Ejemplo:

```text
Qué es una automatización

Cómo funciona un agente IA
```

---

# 7. TOPIC FILTER

Toda temática debe superar los siguientes filtros.

---

## Strategic Alignment

¿Está alineada con la estrategia?

---

## Audience Relevance

¿Es relevante para la audiencia?

---

## Business Relevance

¿Contribuye al objetivo principal?

---

## Content Potential

¿Puede transformarse en contenido útil?

---

Si falla cualquiera de estos filtros:

La temática debe descartarse.

---

# 8. TOPIC PRIORITY SYSTEM

Las temáticas deben clasificarse.

---

## T1

Crítica.

---

## T2

Alta prioridad.

---

## T3

Prioridad media.

---

## T4

Prioridad baja.

---

## T5

Descartada.

---

# 9. TOPIC CATEGORIES

Toda temática debe clasificarse.

---

## Educational

Educar.

---

## Problem Solving

Resolver problemas.

---

## Authority

Construir autoridad.

---

## Awareness

Generar alcance.

---

## Community

Generar interacción.

---

## Conversion

Contribuir a negocio.

---

# 10. OUTPUT STRUCTURE

La salida oficial debe contener:

---

## Topic Summary

Resumen.

---

## High Priority Topics

Temáticas prioritarias.

---

## Secondary Topics

Temáticas secundarias.

---

## Topic Categories

Clasificación.

---

## Strategic Alignment

Relación con objetivos.

---

## Recommended Topics

Lista final recomendada.

---

# 11. OUTPUT RESTRICTIONS

El protocolo NO debe:

* generar publicaciones completas
* generar calendarios
* generar copies
* generar campañas

---

Estas tareas pertenecen a protocolos posteriores.

---

# 12. CHILD PROTOCOLS

Puede alimentar:

```text
MKT-CONTENT-PLAN

MKT-CALENDAR
```

---

# 13. SUCCESS CRITERIA

El protocolo se considera exitoso cuando:

---

El usuario comprende:

* qué temas abordar
* qué temas evitar
* cuáles son prioritarios
* cuáles tienen mayor potencial

---

# 14. CIP COMPLIANCE

---

## HCEP

Eliminar temas irrelevantes.

---

## CRL

Agrupar temáticas por prioridad.

---

## HRR

Mantener continuidad lógica.

---

# 15. FINAL OUTPUT

La salida final debe responder:

```text
¿Qué temas deberíamos abordar?

¿Cuáles son prioritarios?

¿Cuáles generan mayor valor?

¿Cuáles debemos evitar?

¿Cuáles contribuyen mejor a nuestros objetivos?
```

---

END OF PROTOCOL
