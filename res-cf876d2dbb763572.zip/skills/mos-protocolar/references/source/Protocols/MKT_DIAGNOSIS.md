# MARKETING OS

## MKT-DIAGNOSIS

Version: 1.0 Experimental

Category: Analysis Protocol

Protocol ID: MKT-DIAGNOSIS

---

# 1. PURPOSE

MKT-DIAGNOSIS existe para determinar el estado actual de una marca, negocio, proyecto o creador.

Su función es establecer una línea base objetiva antes de generar cualquier estrategia o recomendación.

---

# 2. CORE QUESTION

Este protocolo responde una única pregunta:

```text
¿Dónde estamos actualmente?
```

---

# 3. ACTIVATION

Puede activarse mediante:

```text
//audit

//diagnosis
```

O mediante activación indirecta desde otros protocolos.

---

# 4. INPUTS

Puede analizar:

## Redes Sociales

* Instagram
* TikTok
* LinkedIn
* YouTube
* X
* Facebook

---

## Documentos

* PDF
* DOCX
* TXT
* Markdown

---

## Estrategias

* planes de contenido
* calendarios editoriales
* roadmaps
* auditorías previas

---

## Métricas

* visualizaciones
* alcance
* impresiones
* interacción
* crecimiento
* conversiones

---

## Conversaciones

Información proporcionada por el usuario.

---

# 5. ANALYSIS DIMENSIONS

El protocolo analiza siete dimensiones.

---

## D1 — Presencia

Evalúa:

* plataformas utilizadas
* consistencia visual
* coherencia de marca

---

## D2 — Actividad

Evalúa:

* frecuencia
* consistencia
* continuidad

---

## D3 — Contenido

Evalúa:

* calidad percibida
* utilidad
* relevancia
* alineación temática

---

## D4 — Audiencia

Evalúa:

* interacción
* participación
* respuesta observada

---

## D5 — Posicionamiento

Evalúa:

* claridad del mensaje
* diferenciación
* propuesta de valor

---

## D6 — Rendimiento

Evalúa:

* resultados observables
* formatos ganadores
* formatos débiles

---

## D7 — Objetivos

Evalúa:

* existencia de objetivos
* claridad
* alineación

---

# 6. DECISION LOGIC

El protocolo debe trabajar utilizando evidencia.

---

## Prioridad 1

Datos reales.

---

## Prioridad 2

Documentos proporcionados.

---

## Prioridad 3

Declaraciones del usuario.

---

## Prioridad 4

Inferencias.

---

Las inferencias nunca deben sustituir evidencia.

---

# 7. DETECCIÓN DE FORTALEZAS

Debe identificar:

```text
Qué está funcionando.
```

---

Ejemplos:

* formatos exitosos
* canales fuertes
* posicionamiento claro
* contenido con interacción

---

# 8. DETECCIÓN DE DEBILIDADES

Debe identificar:

```text
Qué limita el crecimiento.
```

---

Ejemplos:

* baja frecuencia
* inconsistencia
* mensaje ambiguo
* falta de diferenciación

---

# 9. DETECCIÓN DE OPORTUNIDADES

Debe identificar:

```text
Qué puede mejorarse.
```

---

Ejemplos:

* canales desaprovechados
* formatos no explorados
* activos reutilizables

---

# 10. DETECCIÓN DE RIESGOS

Debe identificar:

```text
Qué podría afectar negativamente.
```

---

Ejemplos:

* dependencia excesiva de una plataforma
* falta de posicionamiento
* ausencia de objetivos

---

# 11. OUTPUT STRUCTURE

La salida oficial debe contener:

---

## Executive Summary

Resumen ejecutivo.

---

## Current State

Estado actual.

---

## Strengths

Fortalezas.

---

## Weaknesses

Debilidades.

---

## Opportunities

Oportunidades.

---

## Risks

Riesgos.

---

## Diagnostic Conclusion

Conclusión final.

---

# 12. OUTPUT RESTRICTIONS

El protocolo NO debe:

* crear contenido
* generar publicaciones
* diseñar estrategias completas
* construir calendarios

---

Estas funciones pertenecen a otros protocolos.

---

# 13. DEPENDENCIES

No requiere protocolos previos.

---

Puede ejecutarse de forma independiente.

---

# 14. CHILD PROTOCOLS

Puede alimentar:

```text
MKT-STRATEGY

MKT-GROWTH

MKT-TREND

MKT-CONTENT-PLAN

MKT-CALENDAR

MKT-OPTIMIZER
```

---

# 15. SUCCESS CRITERIA

El protocolo se considera exitoso cuando el usuario comprende:

---

## Estado actual

Dónde está.

---

## Fortalezas

Qué debe mantener.

---

## Debilidades

Qué debe corregir.

---

## Oportunidades

Qué debe aprovechar.

---

## Riesgos

Qué debe evitar.

---

# 16. CIP COMPLIANCE

El resultado debe cumplir:

---

HCEP

Priorizar información accionable.

---

CRL

Presentar información de forma clara y escaneable.

---

HRR

Mantener flujo natural y reducir fatiga cognitiva.

---

# 17. FINAL OUTPUT

La salida final debe responder claramente:

```text
¿Dónde estamos actualmente?

¿Dónde están nuestras ventajas?

¿Dónde están nuestros problemas?

¿Qué deberíamos investigar después?
```

---

END OF PROTOCOL
