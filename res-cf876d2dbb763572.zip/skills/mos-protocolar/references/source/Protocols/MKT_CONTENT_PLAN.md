# MARKETING OS

## MKT-CONTENT-PLAN

Version: 1.0 Experimental

Category: Planning Protocol

Protocol ID: MKT-CONTENT-PLAN

---

# 1. PURPOSE

MKT-CONTENT-PLAN existe para transformar temáticas estratégicamente validadas en un plan de contenido estructurado.

Su función es decidir:

* qué contenido crear
* por qué crearlo
* para quién crearlo
* en qué orden crearlo

---

# 2. CORE QUESTION

Este protocolo responde una única pregunta:

¿Qué contenido deberíamos producir?

---

# 3. ACTIVATION

Puede activarse mediante:

```text
//content-plan
```

o indirectamente desde:

```text
//full-plan

//marketing-os
```

---

# 4. DEPENDENCIES

Requiere:

```text
MKT-STRATEGY

MKT-RESEARCH

MKT-TOPIC
```

---

Sin estrategia:

```text
No existe dirección estratégica.
```

---

Sin investigación:

```text
No existen oportunidades suficientemente validadas.
```

---

Sin temáticas:

```text
No existen temas seleccionados para planificar.
```

---

# 5. INPUTS

Puede utilizar:

---

## Diagnóstico

Resultado de:

```text
MKT-DIAGNOSIS
```

---

## Estrategia

Resultado de:

```text
MKT-STRATEGY
```

---

## Investigación

Resultado de:

```text
MKT-RESEARCH
```

---

## Temáticas

Resultado de:

```text
MKT-TOPIC
```

---

## Contexto

Información disponible en la sesión.

---

# 6. CONTENT DIMENSIONS

El protocolo organiza el contenido utilizando cinco dimensiones.

---

## D1 — Objetivo

Cada pieza debe tener un objetivo.

---

Ejemplos:

```text
Alcance

Autoridad

Educación

Comunidad

Conversión
```

---

## D2 — Temática

Cada pieza debe pertenecer a una temática validada.

---

Ejemplo:

```text
IA aplicada

Automatización

Marketing

Productividad
```

---

## D3 — Categoría

Cada pieza debe clasificarse.

---

Ejemplos:

```text
Caso real

Tutorial

Opinión

Actualidad

Herramienta

Error común
```

---

## D4 — Prioridad

Cada pieza debe tener prioridad.

---

```text
P1

P2

P3

P4
```

---

## D5 — Plataforma Recomendada

Cada idea debe indicar:

```text
TikTok

Instagram

LinkedIn

YouTube

Medium

Multiplataforma
```

---

# 7. CONTENT ALLOCATION SYSTEM

El protocolo debe distribuir contenido.

---

## Regla 01

No concentrar todo el contenido en una única categoría.

---

## Regla 02

No concentrar todo el contenido en una única temática.

---

## Regla 03

No concentrar todo el contenido en una única plataforma.

---

## Regla 04

Priorizar contenido alineado con objetivos principales.

---

# 8. CONTENT PRIORITY SYSTEM

---

## P1

Contenido crítico.

---

## P2

Contenido importante.

---

## P3

Contenido complementario.

---

## P4

Contenido opcional.

---

# 9. CONTENT TYPES

El protocolo puede generar:

---

## Casos Reales

Experiencias reales.

---

## Problemas

Dificultades frecuentes.

---

## Soluciones

Métodos y procesos.

---

## Actualidad

Noticias y tendencias.

---

## Herramientas

Recursos útiles.

---

## Opinión

Reflexiones.

---

## Educación

Conceptos y formación.

---

# 10. OUTPUT STRUCTURE

La salida oficial debe contener:

---

## Executive Summary

Resumen del plan.

---

## Content Objectives

Objetivos de contenido.

---

## Priority Content

Contenido prioritario.

---

## Secondary Content

Contenido secundario.

---

## Platform Distribution

Distribución recomendada.

---

## Content Matrix

Matriz de contenido.

---

## Final Recommendations

Recomendaciones.

---

# 11. CONTENT MATRIX

Cada entrada debe incluir:

```text
Temática

Objetivo

Categoría

Prioridad

Plataforma

Justificación
```

---

Ejemplo:

```text
Temática:
IA aplicada

Objetivo:
Autoridad

Categoría:
Caso Real

Prioridad:
P1

Plataforma:
LinkedIn

Justificación:
Alineado con posicionamiento.
```

---

# 12. OUTPUT RESTRICTIONS

El protocolo NO debe:

* generar copies
* generar publicaciones completas
* generar diseños
* generar vídeos

---

Estas funciones pertenecen a herramientas externas.

---

# 13. CHILD PROTOCOLS

Puede alimentar:

```text
MKT-CALENDAR
```

---

# 14. SUCCESS CRITERIA

El protocolo se considera exitoso cuando:

---

El usuario comprende:

* qué contenido crear
* qué contenido priorizar
* qué contenido descartar
* dónde publicarlo

---

# 15. CIP COMPLIANCE

---

## HCEP

Eliminar ideas redundantes.

---

## CRL

Agrupar contenido claramente.

---

## HRR

Mantener flujo lógico.

---

# 16. FINAL OUTPUT

La salida final debe responder:

```text
¿Qué contenido debemos crear?

¿Qué contenido es prioritario?

¿Qué plataforma es más adecuada?

¿Qué contenido debemos posponer?

¿Cómo distribuimos nuestros esfuerzos?
```

---

END OF PROTOCOL
