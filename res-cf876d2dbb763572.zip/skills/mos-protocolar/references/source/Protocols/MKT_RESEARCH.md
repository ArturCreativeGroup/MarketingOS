# MARKETING OS

## MKT-RESEARCH

Version: 1.0 Experimental

Category: Research Protocol

Protocol ID: MKT-RESEARCH

---

# 1. PURPOSE

MKT-RESEARCH existe para identificar oportunidades relevantes alineadas con la estrategia definida previamente.

Su función no es recopilar información.

Su función es encontrar información útil para la toma de decisiones.

---

# 2. CORE QUESTION

Este protocolo responde una única pregunta:

¿Qué deberíamos investigar para acercarnos a nuestros objetivos?

---

# 3. ACTIVATION

Puede activarse mediante:

```text
//research
```

o indirectamente desde:

```text
//content-plan

//full-plan

//marketing-os
```

---

# 4. DEPENDENCIES

Requiere:

```text
MKT-STRATEGY
```

---

Sin estrategia previa debe indicar:

```text
No existe suficiente dirección estratégica para realizar una investigación relevante.
```

---

# 5. INPUTS

Puede utilizar:

---

## Estrategia

Resultados generados por MKT-STRATEGY.

---

## Diagnóstico

Resultados generados por MKT-DIAGNOSIS.

---

## Contexto

Información de la sesión activa.

---

## Plataformas

Canales utilizados.

---

## Audiencia

Información disponible sobre el público objetivo.

---

## Restricciones

Tiempo

Presupuesto

Equipo

Recursos

---

# 6. RESEARCH DIMENSIONS

El protocolo investiga seis dimensiones.

---

## D1 — Tendencias

Busca:

* tendencias emergentes
* cambios de comportamiento
* nuevos formatos
* nuevas tecnologías

---

## D2 — Temáticas

Busca:

* temas compatibles
* temas recurrentes
* temas relevantes

---

## D3 — Oportunidades

Busca:

* vacíos de contenido
* oportunidades de posicionamiento
* oportunidades de crecimiento

---

## D4 — Problemas

Busca:

* preguntas frecuentes
* dificultades recurrentes
* necesidades detectadas

---

## D5 — Casos Reales

Busca:

* ejemplos prácticos
* experiencias
* validaciones
* implementaciones

---

## D6 — Actualidad

Busca:

* noticias
* novedades
* cambios recientes

---

# 7. RESEARCH FILTER

Toda información encontrada debe pasar por los siguientes filtros.

---

## Relevancia

¿Es relevante para la estrategia?

---

## Compatibilidad

¿Es compatible con la marca?

---

## Utilidad

¿Puede transformarse en una acción?

---

## Potencial

¿Tiene potencial de impacto?

---

Si falla cualquier filtro:

Debe descartarse.

---

# 8. RESEARCH PRIORITY SYSTEM

La investigación debe clasificarse.

---

## R1

Crítica.

---

## R2

Alta prioridad.

---

## R3

Media prioridad.

---

## R4

Baja prioridad.

---

## R5

No relevante.

---

# 9. OUTPUT STRUCTURE

La salida oficial debe contener:

---

## Executive Summary

Resumen ejecutivo.

---

## Strategic Alignment

Relación con la estrategia.

---

## Trends

Tendencias detectadas.

---

## Topics

Temáticas recomendadas.

---

## Opportunities

Oportunidades detectadas.

---

## Problems

Problemas identificados.

---

## Real Cases

Casos relevantes.

---

## Research Conclusions

Conclusiones.

---

# 10. OUTPUT RESTRICTIONS

El protocolo NO debe:

* generar publicaciones
* generar copies
* generar calendarios
* generar campañas completas

---

Estas funciones pertenecen a protocolos posteriores.

---

# 11. CHILD PROTOCOLS

Puede alimentar:

```text
MKT-TOPIC

MKT-CONTENT-PLAN

MKT-CALENDAR
```

---

# 12. SUCCESS CRITERIA

El protocolo se considera exitoso cuando identifica:

---

## Qué investigar

---

## Qué ignorar

---

## Qué oportunidades existen

---

## Qué oportunidades tienen mayor potencial

---

# 13. CIP COMPLIANCE

---

## HCEP

Eliminar información innecesaria.

---

## CRL

Agrupar hallazgos por prioridad.

---

## HRR

Mantener continuidad narrativa.

---

# 14. FINAL OUTPUT

La salida final debe responder:

```text
¿Qué oportunidades existen?

¿Qué tendencias importan?

¿Qué temas deberíamos explorar?

¿Qué problemas deberíamos resolver?

¿Qué deberíamos ignorar?
```

---

END OF PROTOCOL
