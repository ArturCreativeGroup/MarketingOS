# MARKETING OS

## MOS-LOG-RENDERER

Version: 1.0 Experimental

Category: Output System

Component ID: MOS-LOG-RENDERER

---

# 1. PURPOSE

MOS-LOG-RENDERER es el componente responsable de transformar información técnica del sistema en mensajes comprensibles para el usuario.

Su función es proteger la experiencia de usuario de la complejidad interna de Marketing OS.

---

# 2. CORE QUESTION

MOS-LOG-RENDERER responde una única pregunta:

¿Cómo debe mostrarse la actividad interna del sistema?

---

# 3. PHILOSOPHY

Los protocolos necesitan logs.

Los usuarios necesitan claridad.

Los logs existen para el sistema.

Las respuestas existen para las personas.

---

# 4. OUTPUT PRIORITY

Prioridad máxima:

Respuesta para usuario.

---

Prioridad secundaria:

Estado del sistema.

---

Prioridad mínima:

Log técnico.

---

# 5. RENDER MODES

## Mode A — User Friendly

Modo por defecto.

---

Transforma:

```text
Audit Protocol Initiated
```

en:

```text
La auditoría está lista para comenzar.
```

---

Transforma:

```text
Research Dependencies Loaded
```

en:

```text
Estoy preparando la investigación.
```

---

Transforma:

```text
Context Engine Initialized
```

en:

```text
He procesado el contexto disponible.
```

---

# 6. SYSTEM STATUS MESSAGES

MOS-LOG-RENDERER debe convertir estados técnicos en estados naturales.

---

Ready

↓

Sistema listo.

---

Loading

↓

Preparando información.

---

Executing

↓

Trabajando en la solicitud.

---

Completed

↓

Proceso finalizado.

---

Failed

↓

Necesito información adicional o corregir un problema antes de continuar.

---

# 7. TECHNICAL LOG MODE

Activado únicamente mediante:

```text
//logs
```

o

Modo desarrollador.

---

En este modo se permite mostrar actividad técnica.

---

# 8. LOG VISUAL FORMAT

Si un log debe mostrarse:

Debe renderizarse utilizando formato consola.

---

Ejemplo:

```text
[LOG]
Loading Registry...
Loading Protocols...
Building Context...
System Ready.
```

---

Nunca debe mezclarse con el contenido principal.

---

# 9. LOG SEPARATION RULE

Contenido para usuario:

Texto normal.

---

Contenido técnico:

Formato consola.

---

Ambos deben permanecer visualmente separados.

---

# 10. CIP INTEGRATION

Antes de mostrar cualquier log:

Aplicar:

HCEP

↓

CRL

↓

HRR

---

Objetivo:

Reducir carga cognitiva.

---

# 11. RESTRICTIONS

MOS-LOG-RENDERER NO debe:

* ejecutar protocolos
* modificar resultados
* alterar estrategias
* alterar diagnósticos

---

Su única responsabilidad es renderizar.

---

# 12. SUCCESS CRITERIA

MOS-LOG-RENDERER se considera exitoso cuando:

* el usuario comprende qué está ocurriendo
* la complejidad técnica permanece oculta
* los logs siguen disponibles para depuración
* la experiencia se mantiene limpia

---

# 13. PRINCIPLE

Los sistemas necesitan logs.

Las personas necesitan significado.

---

# 14. FINAL DEFINITION

MOS-LOG-RENDERER es el componente responsable de traducir la actividad interna de Marketing OS en una experiencia comprensible, limpia y alineada con los principios de CIP.

---

END OF COMPONENT
