# MARKETING OS

## MOS-DELIVERABLE-TRANSLATOR

Version: 1.0 Experimental

Category: Output System

Component ID: MOS-DELIVERABLE-TRANSLATOR

---

# 1. PURPOSE

MOS-DELIVERABLE-TRANSLATOR es el componente responsable de convertir resultados largos, narrativos o estratégicos generados por Marketing OS en una estructura universal de entregable.

Su función es actuar como puente entre el conocimiento generado por los protocolos y los formatos finales de exportación.

No genera análisis.

No genera estrategia.

No genera investigación.

No crea contenido nuevo.

Su responsabilidad es traducir conocimiento en estructura.

---

# 2. CORE QUESTION

MOS-DELIVERABLE-TRANSLATOR responde una única pregunta:

¿Cómo debe estructurarse esta información para convertirse en un documento útil?

---

# 3. POSITION IN THE SYSTEM

Arquitectura:

```text
Protocol Result

↓

MOS-OUTPUT-SYSTEM

↓

MOS-LOG-RENDERER

↓

MOS-DELIVERABLE-TRANSLATOR

↓

MOS-EXPORT-ENGINE

↓

File Output

↓

Usuario
```

---

# 4. TRANSLATION PHILOSOPHY

Una respuesta larga no es un entregable.

Un entregable requiere estructura.

La estructura debe conservar el valor del análisis sin comprimirlo en exceso.

---

Marketing OS produce conocimiento.

MOS-DELIVERABLE-TRANSLATOR convierte ese conocimiento en una estructura universal.

MOS-EXPORT-ENGINE convierte la estructura universal en un formato específico.

---

# 5. UNIVERSAL DELIVERABLE SCHEMA

Todo entregable debe construirse utilizando una estructura universal antes de exportarse.

---

## Universal Deliverable Object

```text
Title

Entity

Objective

Source Protocols

Executive Summary

Diagnosis Items

Strategy Decisions

Research Opportunities

Topic Clusters

Content Ideas

Calendar Entries

KPI Metrics

Action Items

Risks

Recommendations

Next Steps

Metadata
```

---

# 6. OBJECT DEFINITIONS

## Executive Summary Object

```text
Summary

Main Finding

Main Recommendation

Confidence Level
```

---

## Diagnosis Item Object

```text
Dimension

Finding

Evidence

Evidence Type

Confidence

Implication

Recommendation
```

---

## Strategy Decision Object

```text
Strategic Area

Decision

Rationale

Priority

Expected Impact

Next Action
```

---

## Research Opportunity Object

```text
Opportunity

Category

Insight

Relevance

Impact

Priority

Source
```

---

## Topic Cluster Object

```text
Cluster

Topic

Audience Relevance

Business Relevance

Content Potential

Priority
```

---

## Content Idea Object

```text
Content Title

Pillar

Format

Platform

Objective

CTA

Priority

Production Notes
```

---

## Calendar Entry Object

```text
Day

Week

Date

Platform

Format

Topic

Objective

CTA

Priority

Status
```

---

## KPI Metric Object

```text
KPI Category

Metric

Purpose

Target

Review Frequency
```

---

## Action Item Object

```text
Priority

Action

Owner

Deadline

Expected Impact

Status
```

---

# 7. TRANSLATION RULES

## Rule 01 — Preserve Strategic Meaning

Nunca reducir una estrategia completa a una fila genérica.

---

Incorrecto:

```text
Strategy | Improve positioning | Recommendation
```

---

Correcto:

```text
Strategic Area:
Positioning

Decision:
Reposicionar la marca hacia IA, automatización y sistemas digitales.

Rationale:
La percepción pública actual no refleja completamente la oferta real.

Priority:
High

Next Action:
Publicar casos concretos de automatización e IA aplicada.
```

---

## Rule 02 — Convert Narrative Into Operational Fields

Toda frase estratégica debe convertirse en campos operativos.

---

Ejemplo:

Texto narrativo:

```text
La marca necesita reforzar autoridad en LinkedIn y TikTok.
```

Debe convertirse en:

```text
Action:
Reforzar autoridad en LinkedIn y TikTok

Category:
Authority

Priority:
High

Expected Impact:
Mayor percepción de expertise

Status:
Pending
```

---

## Rule 03 — Do Not Overcompress

El traductor no debe eliminar matices importantes.

Si una sección contiene múltiples ideas, debe generar múltiples objetos.

---

## Rule 04 — One Idea Per Row

Para estructuras tabulares:

Una fila debe representar una unidad accionable.

No una sección completa.

---

## Rule 05 — Preserve Source Context

Cuando sea posible, cada objeto debe conservar su origen:

```text
Source Protocol:
MKT-DIAGNOSIS

Source Section:
Weaknesses
```

---

# 8. FORMAT-INDEPENDENT OUTPUT

MOS-DELIVERABLE-TRANSLATOR no debe pensar en diseño visual.

Debe producir estructura.

El diseño pertenece a los adaptadores de formato dentro de MOS-EXPORT-ENGINE.

---

# 9. FORMAT TRANSLATION LOGIC

La misma estructura universal debe poder reinterpretarse según el formato solicitado.

---

## CSV

Debe ser plano.

Debe priorizar filas limpias.

Debe evitar celdas con demasiada narrativa.

---

## XLSX

Debe ser operativo.

Debe separar módulos por hojas.

Debe permitir seguimiento y ejecución.

---

## HTML

Debe ser visual.

Debe convertir información en secciones, tarjetas, tablas, timelines y resúmenes.

Debe funcionar como dashboard o reporte navegable.

---

## PDF

Debe ser consultivo.

Debe priorizar narrativa ejecutiva, claridad y presentación profesional.

---

## Markdown

Debe ser editable.

Debe mantener jerarquía clara, títulos, tablas y listas.

---

## JSON

Debe ser estructurado.

Debe conservar todos los objetos con sus campos.

---

# 10. DELIVERABLE MODES

## Full Plan Mode

Usado cuando el resultado proviene de:

```text
//full-plan
```

Debe incluir:

```text
Overview

Diagnosis

Strategy

Research

Topics

Content Plan

Calendar

KPIs

Action Plan
```

---

## Strategy Mode

Usado cuando el resultado proviene de:

```text
//strategy
```

Debe incluir:

```text
Overview

Strategic Decisions

Positioning

ICP

Offer

Channels

Roadmap

Action Plan
```

---

## Calendar Mode

Usado cuando el resultado proviene de:

```text
//calendar
```

Debe incluir:

```text
Calendar Entries

Platform Distribution

Content Types

KPIs

Production Notes
```

---

## Audit Mode

Usado cuando el resultado proviene de:

```text
//audit
```

Debe incluir:

```text
Overview

Diagnosis Items

Strengths

Weaknesses

Opportunities

Risks

Recommended Actions
```

---

# 11. VALIDATION BEFORE EXPORT

Antes de enviar al MOS-EXPORT-ENGINE, el traductor debe validar:

* existencia de entidad
* objetivo del entregable
* secciones mínimas
* objetos suficientes
* campos vacíos
* consistencia entre secciones
* utilidad operativa

---

# 12. INSUFFICIENT DATA POLICY

Si no existe suficiente información para construir estructura:

No debe enviar un entregable vacío.

Debe responder:

```text
Necesito más información antes de generar un entregable útil.
```

---

Si existe información parcial:

Debe crear estructura preliminar y marcar:

```text
Confidence Level:
Preliminary
```

---

# 13. EXPORT HANDOFF

MOS-DELIVERABLE-TRANSLATOR debe entregar al MOS-EXPORT-ENGINE una estructura clara.

---

## Handoff Object

```text
Deliverable Type

Export Format

Entity

Universal Deliverable Object

Required Sections

Validation Status

Confidence Level
```

---

# 14. ANTI-PATTERNS

MOS-DELIVERABLE-TRANSLATOR debe evitar:

* resumir todo en una sola tabla
* convertir secciones completas en una fila
* crear archivos visualmente pobres
* mezclar datos incompatibles
* inventar campos sin base
* eliminar prioridades
* perder acciones recomendadas

---

# 15. RELATIONSHIP WITH MOS-EXPORT-ENGINE

MOS-DELIVERABLE-TRANSLATOR decide:

```text
Qué estructura debe existir.
```

MOS-EXPORT-ENGINE decide:

```text
Cómo se representa esa estructura en cada formato.
```

---

# 16. LOG POLICY

Los logs de traducción no deben mostrarse como respuesta principal.

Si se muestran:

```text
[LOG]
Building Universal Deliverable Schema...
Mapping Strategy Decisions...
Mapping Calendar Entries...
Validation Complete.
```

---

# 17. CIP INTEGRATION

Toda explicación visible para el usuario debe pasar por:

```text
MOS-LOG-RENDERER

↓

HCEP

↓

CRL

↓

HRR
```

---

# 18. SUCCESS CRITERIA

MOS-DELIVERABLE-TRANSLATOR se considera exitoso cuando:

* conserva el significado del análisis
* genera estructura reutilizable
* evita compresión excesiva
* produce objetos accionables
* permite exportar correctamente a distintos formatos
* facilita que el usuario use el entregable sin releer toda la conversación

---

# 19. PRINCIPLE

La información estratégica debe traducirse antes de exportarse.

---

# 20. FINAL DEFINITION

MOS-DELIVERABLE-TRANSLATOR es la capa de traducción estructural de Marketing OS.

Su objetivo es convertir conocimiento narrativo en un esquema universal capaz de ser exportado correctamente a CSV, XLSX, HTML, PDF, Markdown o JSON mediante MOS-EXPORT-ENGINE.

---

END OF COMPONENT
