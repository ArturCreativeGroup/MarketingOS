# MARKETING OS

## MOS-INDEX

Version: 1.0 Experimental

Document ID: MOS-INDEX

---

# 1. PURPOSE

MOS-INDEX es el mapa estructural de Marketing OS.

Su función es describir la organización física y lógica del sistema.

MOS-INDEX permite localizar componentes, protocolos, workflows y recursos.

MOS-BOOTSTRAP utiliza este documento para comprender la estructura general del sistema.

---

# 2. CORE QUESTION

MOS-INDEX responde una única pregunta:

¿Dónde se encuentra cada componente del sistema?

---

# 3. ROOT STRUCTURE

```text
MarketingOS/

├── Commands/
├── Context Engine/
├── Core/
├── Documentation/
├── Inputs/
├── Outputs/
├── Protocols/
└── CIP/
```

---

# 4. CORE DIRECTORY

Ubicación:

```text
Core/
```

---

Componentes:

```text
MOS_BOOTSTRAP.md

MOS_CORE.md
```

---

Responsabilidad:

```text
Inicialización

Coordinación

Orquestación

Gestión de workflows
```

---

# 5. COMMAND DIRECTORY

Ubicación:

```text
Commands/
```

---

Componentes:

```text
MOS_COMMAND_ROUTER.md

MOS_LAUNCHER.md
```

---

Responsabilidad:

```text
Interpretación

Resolución

Activación
```

---

# 6. CONTEXT DIRECTORY

Ubicación:

```text
Context Engine/
```

---

Componentes:

```text
MOS_CONTEXT_ENGINE.md
```

---

Responsabilidad:

```text
Gestión contextual

Estado de sesión

Continuidad operativa
```

---

# 7. INPUT DIRECTORY

Ubicación:

```text
Inputs/
```

---

Componentes:

```text
MOS_INPUT_SYSTEM.md
```

---

Responsabilidad:

```text
Clasificación

Validación

Preparación de artefactos
```

---

# 8. OUTPUT DIRECTORY

Ubicación:

```text
Outputs/
```

---

Componentes:

```text
MOS_OUTPUT_SYSTEM.md

MOS_LOG_RENDERER.md

MOS_DELIVERABLE_TRANSLATOR.md

MOS_EXPORT_ENGINE.md
```

---

Responsabilidad:

```text
Construcción de entregables

Renderizado de logs

Traducción estructural

Exportación de archivos

Adaptación de formatos

Compatibilidad con XLSX, CSV, HTML, PDF, Markdown y JSON
```

---

# 9. DOCUMENTATION DIRECTORY

Ubicación:

```text
Documentation/
```

---

Componentes:

```text
MARKETING_OS_MASTER.md

MARKETING_OS_ARCHITECTURE.md

MARKETING_OS_COMMANDS.md

MARKETING_OS_WORKFLOWS.md

MOS_MANIFEST.md

MOS_INDEX.md

MOS_REGISTRY.md
```

---

Responsabilidad:

```text
Definición del sistema

Arquitectura

Registro

Documentación
```

---

# 10. PROTOCOL DIRECTORY

Ubicación:

```text
Protocols/
```

---

Protocolos activos:

```text
MKT_PROTOCOL_STANDARD.md

MKT_DIAGNOSIS.md

MKT_STRATEGY.md

MKT_RESEARCH.md

MKT_TOPIC.md

MKT_CONTENT_PLAN.md

MKT_CALENDAR.md

MKT_PERFORMANCE.md

MKT_OPTIMIZER.md
```

---

Responsabilidad:

```text
Diagnóstico

Estrategia

Investigación

Planificación

Optimización
```

---

# 11. CIP DIRECTORY

Ubicación:

```text
CIP/
```

---

Componentes:

```text
HumanCommunicationEfficiencyProtocol.md

CognitiveRenderingLayer.md

HumanRhythmRendering.md
```

---

Responsabilidad:

```text
Comunicación cognitiva

Renderizado cognitivo

Ritmo humano
```

---

# 12. LOGICAL ARCHITECTURE

Vista lógica.

```text
Usuario

↓

MOS_LAUNCHER

↓

MOS_BOOTSTRAP

↓

MOS_CORE

↓

Protocols

↓

MOS_OUTPUT_SYSTEM

↓

MOS_LOG_RENDERER

↓

MOS_DELIVERABLE_TRANSLATOR
(optional when file export is requested)

↓

MOS_EXPORT_ENGINE
(optional when file export is requested)

↓

CIP

↓

Usuario
```

---

# 13. PROTOCOL CHAIN

Cadena principal.

```text
MKT-DIAGNOSIS

↓

MKT-STRATEGY

↓

MKT-RESEARCH

↓

MKT-TOPIC

↓

MKT-CONTENT-PLAN

↓

MKT-CALENDAR

↓

MKT-PERFORMANCE

↓

MKT-OPTIMIZER
```

---

# 14. WORKFLOW MAP

```text
Analysis Workflow

Strategy Workflow

Research Workflow

Topic Workflow

Content Plan Workflow

Calendar Workflow

Performance Workflow

Optimization Workflow

Master Workflow

Bootstrap Workflow
```

---

# 15. FUTURE EXPANSION

Directorios reservados.

```text
Templates/

Exports/

Assets/

Integrations/

Skills/
```

---

Estos directorios no forman parte de Marketing OS V1.

---

# 16. BOOTSTRAP REFERENCE

MOS-BOOTSTRAP debe cargar:

```text
MOS_MANIFEST
```

↓

```text
MOS_INDEX
```

↓

```text
MOS_REGISTRY
```

↓

```text
MOS_CONTEXT_ENGINE
```

↓

```text
MOS_CORE
```

---

# 17. PRINCIPLE

MOS_INDEX no define comportamiento.

MOS_INDEX define ubicación y estructura.

---

# 18. FINAL DEFINITION

MOS-INDEX es el mapa estructural oficial de Marketing OS.

Todo componente debe poder localizarse mediante este documento.

---

END OF DOCUMENT
