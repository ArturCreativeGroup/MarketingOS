# MARKETING OS

## Command Dictionary

Version: 0.1 Experimental

---

# 1. PROPÓSITO

Este documento define el sistema oficial de comandos de Marketing OS.

Los comandos permiten activar workflows complejos mediante instrucciones cortas y consistentes.

Marketing OS utiliza el prefijo:

```text
//
```

para diferenciar comandos protocolares de instrucciones naturales.

---

# 2. FILOSOFÍA

Los comandos no representan funciones.

Representan intenciones.

---

Ejemplo incorrecto:

```text
//generate-post
```

---

Ejemplo correcto:

```text
//strategy
```

Porque Marketing OS no se centra en producir contenido.

Se centra en producir dirección.

---

# 3. ESTRUCTURA

Formato oficial:

```text
//command
```

---

Formato con parámetros:

```text
//command parameter
```

---

Formato avanzado:

```text
//command parameter:value
```

---

# 4. TIPOS DE COMANDOS

Marketing OS divide los comandos en cinco categorías.

---

## Analysis Commands

Analizar.

---

## Strategy Commands

Decidir.

---

## Research Commands

Investigar.

---

## Planning Commands

Planificar.

---

## Optimization Commands

Mejorar.

---

# 5. ANALYSIS COMMANDS

---

## //audit

Objetivo:

Realizar una auditoría general.

---

Activa:

```text
MKT-DIAGNOSIS

MKT-CONTENT-AUDIT

MKT-AUDIENCE
```

---

Input esperado:

* redes sociales
* capturas
* métricas
* documentos

---

Output:

Diagnóstico completo.

---

## //diagnosis

Objetivo:

Analizar situación actual.

---

Activa:

```text
MKT-DIAGNOSIS
```

---

Output:

Estado actual.

---

## //audience

Objetivo:

Analizar audiencia.

---

Activa:

```text
MKT-AUDIENCE
```

---

Output:

Perfil de audiencia.

---

## //positioning

Objetivo:

Analizar posicionamiento.

---

Activa:

```text
MKT-POSITIONING
```

---

Output:

Informe de posicionamiento.

---

# 6. STRATEGY COMMANDS

---

## //strategy

Objetivo:

Construir estrategia.

---

Activa:

```text
MKT-STRATEGY

MKT-OBJECTIVES

MKT-GROWTH
```

---

Output:

Estrategia general.

---

## //objectives

Objetivo:

Definir objetivos.

---

Activa:

```text
MKT-OBJECTIVES
```

---

Output:

Objetivos priorizados.

---

## //growth

Objetivo:

Detectar oportunidades de crecimiento.

---

Activa:

```text
MKT-GROWTH
```

---

Output:

Plan de crecimiento.

---

# 7. RESEARCH COMMANDS

---

## //research

Objetivo:

Investigación general.

---

Activa:

```text
MKT-TREND

MKT-NEWS

MKT-OPPORTUNITY
```

---

Output:

Informe de oportunidades.

---

## //trends

Objetivo:

Detectar tendencias.

---

Activa:

```text
MKT-TREND
```

---

Output:

Tendencias relevantes.

---

## //opportunities

Objetivo:

Detectar oportunidades.

---

Activa:

```text
MKT-OPPORTUNITY
```

---

Output:

Lista priorizada.

---

## //topics

Objetivo:

Encontrar temas compatibles.

---

Activa:

```text
MKT-TOPIC
```

---

Output:

Temáticas recomendadas.

---

# 8. PLANNING COMMANDS

---

## //content-plan

Objetivo:

Construir plan de contenido.

---

Activa:

```text
MKT-STRATEGY

↓

MKT-TOPIC

↓

MKT-CONTENT-PLAN
```

---

Output:

Plan de contenido.

---

## //calendar

Objetivo:

Construir calendario editorial.

---

Activa:

```text
MKT-CALENDAR
```

---

Output:

Calendario.

---

## //roadmap

Objetivo:

Construir roadmap.

---

Activa:

```text
MKT-ROADMAP
```

---

Output:

Plan de ejecución.

---

# 9. OPTIMIZATION COMMANDS

---

## //performance

Objetivo:

Analizar resultados.

---

Activa:

```text
MKT-PERFORMANCE
```

---

Output:

Informe de rendimiento.

---

## //optimize

Objetivo:

Detectar mejoras.

---

Activa:

```text
MKT-PERFORMANCE

↓

MKT-OPTIMIZER
```

---

Output:

Recomendaciones.

---

# 10. WORKFLOW COMMANDS

Estos comandos ejecutan múltiples protocolos.

---

## //full-plan

Workflow completo.

---

Activa:

```text
MKT-DIAGNOSIS

↓

MKT-STRATEGY

↓

MKT-TREND

↓

MKT-OPPORTUNITY

↓

MKT-CONTENT-PLAN

↓

MKT-CALENDAR
```

---

Output:

Plan completo.

---

## //marketing-os

Comando maestro.

---

Activa:

Workflow completo de Marketing OS.

---

Output:

Diagnóstico

*

Estrategia

*

Investigación

*

Planificación

*

Calendario

---

# 11. PRINCIPIOS

---

Principio 01

Un comando debe representar una intención.

---

Principio 02

Un comando no debe representar una tarea técnica.

---

Principio 03

Los comandos deben ser memorables.

---

Principio 04

Los comandos deben ser escalables.

---

Principio 05

Un comando puede activar múltiples protocolos.

---

# 12. FUTURAS EXPANSIONES

Ejemplos:

```text
//campaign

//launch

//seo

//newsletter

//competitor

//funnel

//ads
```

---

Estas expansiones no modifican la arquitectura principal.

---

END OF DOCUMENT
