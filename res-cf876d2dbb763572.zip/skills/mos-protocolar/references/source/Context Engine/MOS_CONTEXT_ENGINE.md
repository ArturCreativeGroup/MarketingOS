# MARKETING OS

## MOS-CONTEXT-ENGINE

Version: 1.0 Experimental

Category: Context System

Component ID: MOS-CONTEXT-ENGINE

---

# 1. PURPOSE

MOS-CONTEXT-ENGINE es el sistema responsable de mantener el contexto operativo de Marketing OS durante la sesión activa.

Su función es preservar continuidad.

No almacena memoria permanente.

No conserva información entre conversaciones.

No posee conocimiento histórico global.

Su responsabilidad es gestionar el contexto disponible durante la ejecución actual.

---

# 2. CORE QUESTION

MOS-CONTEXT-ENGINE responde una única pregunta:

¿Qué sabemos actualmente sobre este caso?

---

# 3. POSITION IN THE SYSTEM

Arquitectura:

```text
Usuario

↓

Inputs

↓

MOS-CONTEXT-ENGINE

↓

MOS-CORE

↓

Protocols

↓

Outputs
```

---

# 4. DEFINITIONS

---

## Context

Información disponible durante la sesión activa.

---

## State

Estado actual del proyecto analizado.

---

## Artifact

Elemento proporcionado o generado durante la sesión.

---

## Session

Espacio temporal donde existe el contexto.

---

# 5. CONTEXT SOURCES

MOS-CONTEXT-ENGINE puede construir contexto utilizando:

---

## Conversaciones

Mensajes del usuario.

---

## Archivos

Documentos proporcionados.

---

## Imágenes

Capturas y recursos visuales.

---

## Estrategias

Estrategias generadas.

---

## Diagnósticos

Diagnósticos previos.

---

## Calendarios

Calendarios construidos.

---

## Informes

Resultados generados.

---

# 6. CONTEXT TYPES

---

## User Context

Información del usuario.

---

Ejemplos:

```text
Objetivos

Preferencias

Restricciones
```

---

## Business Context

Información de la marca.

---

Ejemplos:

```text
Sector

Servicios

Productos

Audiencia
```

---

## Marketing Context

Información de marketing.

---

Ejemplos:

```text
Plataformas

Rendimiento

Posicionamiento
```

---

## Session Context

Información generada durante la sesión.

---

Ejemplos:

```text
Diagnósticos

Investigaciones

Calendarios
```

---

# 7. CONTEXT STATES

MOS-CONTEXT-ENGINE debe mantener cuatro estados.

---

## Active

Información vigente.

---

## Archived

Información antigua pero útil.

---

## Deprecated

Información reemplazada.

---

## Invalid

Información descartada.

---

# 8. CONTEXT OBJECT MODEL

El contexto debe estructurarse mediante objetos.

---

## User Object

```text
Nombre

Objetivos

Restricciones

Preferencias
```

---

## Business Object

```text
Marca

Sector

Audiencia

Canales
```

---

## Strategy Object

```text
Objetivo principal

Objetivos secundarios

Prioridades
```

---

## Content Object

```text
Temáticas

Planes

Calendarios
```

---

## Performance Object

```text
Métricas

Resultados

Patrones
```

---

# 9. CONTEXT UPDATE RULES

Regla 01

La información más reciente tiene prioridad.

---

Regla 02

La evidencia tiene prioridad sobre las inferencias.

---

Regla 03

La información explícita tiene prioridad sobre supuestos.

---

Regla 04

Los cambios deben actualizar el estado correspondiente.

---

# 10. CONTEXT LIFECYCLE

Creación

↓

Actualización

↓

Utilización

↓

Reemplazo

↓

Finalización de sesión

---

Al finalizar la sesión:

```text
Context Destroyed
```

---

# 11. CONTEXT ACCESS

MOS-CONTEXT-ENGINE puede ser consultado por:

---

MOS-CORE

---

MKT-DIAGNOSIS

---

MKT-STRATEGY

---

MKT-RESEARCH

---

MKT-TOPIC

---

MKT-CONTENT-PLAN

---

MKT-CALENDAR

---

MKT-PERFORMANCE

---

MKT-OPTIMIZER

---

# 12. CONTEXT RESTRICTIONS

MOS-CONTEXT-ENGINE NO puede:

---

Crear estrategias.

---

Modificar protocolos.

---

Generar contenido.

---

Tomar decisiones.

---

Su única función es gestionar contexto.

---

# 13. CONTEXT CONSISTENCY

Antes de entregar información:

Debe verificar:

---

Duplicados.

---

Conflictos.

---

Datos obsoletos.

---

Datos inválidos.

---

# 14. CONTEXT RECOVERY

Si existe información incompleta:

MOS-CONTEXT-ENGINE debe:

---

Identificar vacíos.

---

Solicitar contexto adicional.

---

Marcar incertidumbre.

---

# 15. SUCCESS CRITERIA

MOS-CONTEXT-ENGINE se considera exitoso cuando:

---

Mantiene continuidad.

---

Reduce repeticiones.

---

Evita contradicciones.

---

Permite que los protocolos trabajen sobre información coherente.

---

# 16. PRINCIPLE

MOS-CONTEXT-ENGINE no recuerda.

MOS-CONTEXT-ENGINE contextualiza.

---

# 17. FINAL DEFINITION

MOS-CONTEXT-ENGINE es la fuente temporal de verdad utilizada por Marketing OS durante la sesión activa.

Toda decisión debe construirse utilizando el contexto disponible y validado.

---

END OF COMPONENT
