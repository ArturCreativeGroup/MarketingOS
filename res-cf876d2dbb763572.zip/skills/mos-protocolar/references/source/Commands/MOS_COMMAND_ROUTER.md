# MARKETING OS

## MOS-COMMAND-ROUTER

Version: 1.0 Experimental

Category: Command System

Component ID: MOS-COMMAND-ROUTER

---

# 1. PURPOSE

MOS-COMMAND-ROUTER es el componente responsable de traducir comandos de usuario en ejecuciones protocolares.

Su función es actuar como intérprete entre la intención del usuario y los componentes internos de Marketing OS.

No ejecuta protocolos.

No analiza información.

No toma decisiones de marketing.

Su responsabilidad es resolver comandos.

---

# 2. CORE QUESTION

MOS-COMMAND-ROUTER responde una única pregunta:

¿Qué debe ejecutarse?

---

# 3. POSITION IN THE SYSTEM

Arquitectura:

Usuario

↓

MOS-COMMAND-ROUTER

↓

MOS-CORE

↓

Protocols

↓

Outputs

---

# 4. COMMAND PHILOSOPHY

Los comandos representan intenciones.

No representan funciones técnicas.

---

Incorrecto:

```text
//generate-post
```

---

Correcto:

```text
//strategy
```

---

Porque el usuario expresa una intención.

MOS decide cómo resolverla.

---

# 5. COMMAND PREFIX

Marketing OS utiliza:

```text
//
```

como prefijo oficial de activación.

---

Ejemplos:

```text
//audit

//strategy

//research

//content-plan

//calendar

//optimize
```

---

# 6. COMMAND TYPES

Los comandos se clasifican en cinco grupos.

---

## Analysis Commands

Analizar.

---

## Strategy Commands

Decidir.

---

## Research Commands

Investigar.

---

## Planning Commands

Planificar.

---

## Optimization Commands

Mejorar.

---

# 7. COMMAND RESOLUTION FLOW

Todo comando debe seguir el siguiente flujo.

Comando

↓

Validación

↓

Resolución

↓

Activación

↓

MOS-CORE

---

# 8. VALIDATION RULES

Antes de resolver un comando:

MOS-COMMAND-ROUTER debe verificar:

---

Formato válido.

---

Comando existente.

---

Dependencias mínimas.

---

Compatibilidad con el sistema.

---

# 9. SINGLE COMMAND RESOLUTION

Ejemplo:

```text
//strategy
```

---

Resolución:

```text
Activate:

MKT-STRATEGY
```

---

Entrega:

```text
MOS-CORE
```

---

# 10. MULTI COMMAND RESOLUTION

Algunos comandos representan workflows.

---

Ejemplo:

```text
//full-plan
```

---

Resolución:

```text
MKT-DIAGNOSIS

↓

MKT-STRATEGY

↓

MKT-RESEARCH

↓

MKT-TOPIC

↓

MKT-CONTENT-PLAN

↓

MKT-CALENDAR
```

---

Entrega:

```text
MOS-CORE
```

---

# 11. COMMAND REGISTRY

El Command Router debe consultar el registro oficial.

---

## Analysis

```text
//audit

//diagnosis

//audience

//positioning
```

---

## Strategy

```text
//strategy

//objectives

//growth
```

---

## Research

```text
//research

//topics

//trends

//opportunities
```

---

## Planning

```text
//content-plan

//calendar

//roadmap
```

---

## Optimization

```text
//performance

//optimize
```

---

## Workflows

```text
//full-plan

//marketing-os
```

---

# 12. PARAMETER SUPPORT

Los comandos pueden incluir parámetros.

---

Ejemplo:

```text
//calendar 30
```

---

Interpretación:

```text
Generate:

30 Day Calendar
```

---

Ejemplo:

```text
//calendar 90
```

---

Interpretación:

```text
Generate:

90 Day Calendar
```

---

# 13. UNKNOWN COMMANDS

Si un comando no existe:

MOS-COMMAND-ROUTER debe:

---

Rechazar ejecución.

---

Informar error.

---

Sugerir comandos compatibles.

---

Ejemplo:

```text
Unknown Command:

//viral-content
```

---

Respuesta:

```text
Did you mean:

//content-plan

//research

//strategy
```

---

# 14. COMMAND PRIORITY

Prioridad de resolución.

---

Nivel 1

Comandos explícitos.

---

Nivel 2

Comandos workflow.

---

Nivel 3

Interpretación contextual.

---

# 15. NATURAL LANGUAGE FALLBACK

Si no existe comando:

Marketing OS puede funcionar mediante lenguaje natural.

---

Ejemplo:

```text
Necesito un plan de contenido para Instagram.
```

---

MOS-COMMAND-ROUTER puede interpretar:

```text
Intent:

//content-plan
```

---

Sin necesidad de comando explícito.

---

# 16. RESTRICTIONS

MOS-COMMAND-ROUTER NO puede:

---

Ejecutar protocolos.

---

Modificar contexto.

---

Generar outputs.

---

Tomar decisiones de marketing.

---

Estas responsabilidades pertenecen a otros componentes.

---

# 17. SUCCESS CRITERIA

MOS-COMMAND-ROUTER se considera exitoso cuando:

---

Interpreta correctamente la intención.

---

Resuelve correctamente el comando.

---

Activa correctamente el workflow.

---

Entrega correctamente la resolución a MOS-CORE.

---

# 18. PRINCIPLE

MOS-COMMAND-ROUTER no ejecuta.

MOS-COMMAND-ROUTER traduce.

---

# 19. FINAL DEFINITION

MOS-COMMAND-ROUTER es la capa de interpretación oficial de Marketing OS.

Su función es convertir comandos e intenciones en instrucciones ejecutables para MOS-CORE.

---

END OF COMPONENT
