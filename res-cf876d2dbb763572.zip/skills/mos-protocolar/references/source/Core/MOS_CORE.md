# MARKETING OS

## MOS-CORE

Version: 1.0 Experimental

Category: Core System

Component ID: MOS-CORE

---

# 1. PURPOSE

MOS-CORE es el núcleo operativo de Marketing OS.

Su responsabilidad es coordinar todos los componentes del sistema.

No realiza diagnósticos.

No genera estrategias.

No realiza investigación.

No crea calendarios.

MOS-CORE únicamente coordina.

---

# 2. CORE QUESTION

MOS-CORE responde una única pregunta:

¿Cómo debe ejecutarse Marketing OS?

---

# 3. POSITION IN THE SYSTEM

Arquitectura general:

```text
Usuario

↓

Commands

↓

MOS-CORE

↓

Protocols

↓

Outputs

↓

CIP

↓

Respuesta Final
```

---

# 4. RESPONSIBILITIES

MOS-CORE es responsable de:

---

## Routing

Determinar qué protocolo debe ejecutarse.

---

## Validation

Validar requisitos.

---

## Dependency Management

Gestionar dependencias.

---

## Workflow Execution

Coordinar workflows.

---

## Context Synchronization

Sincronizar contexto.

---

## Output Assembly

Construir resultados finales.

---

# 5. NON-RESPONSIBILITIES

MOS-CORE nunca debe:

---

Generar estrategias.

---

Generar contenido.

---

Generar calendarios.

---

Tomar decisiones especializadas.

---

Estas tareas pertenecen a protocolos.

---

# 6. EXECUTION MODEL

MOS-CORE funciona mediante activación protocolar.

---

Ejemplo:

```text
//strategy
```

---

MOS-CORE interpreta:

```text
Command:
strategy
```

---

Consulta:

```text
MOS Command Router
```

---

Resultado:

```text
Activate:

MKT-STRATEGY
```

---

# 7. WORKFLOW MANAGEMENT

MOS-CORE soporta:

---

## Single Protocol Execution

Un único protocolo.

---

Ejemplo:

```text
//strategy
```

---

## Multi Protocol Execution

Múltiples protocolos.

---

Ejemplo:

```text
//full-plan
```

---

Workflow:

```text
MKT-DIAGNOSIS

↓

MKT-STRATEGY

↓

MKT-RESEARCH

↓

MKT-TOPIC

↓

MKT-CONTENT-PLAN

↓

MKT-CALENDAR
```

---

# 8. DEPENDENCY VALIDATION

Antes de ejecutar un protocolo:

MOS-CORE debe verificar dependencias.

---

Ejemplo:

```text
MKT-CALENDAR
```

---

Requiere:

```text
MKT-CONTENT-PLAN
```

---

Si la dependencia no existe:

MOS-CORE debe:

---

Detener ejecución.

---

Informar dependencia faltante.

---

Sugerir siguiente paso.

---

# 9. CONTEXT INTEGRATION

MOS-CORE utiliza:

```text
MOS-CONTEXT-ENGINE
```

---

Para:

* leer contexto
* actualizar contexto
* registrar resultados

---

MOS-CORE no almacena contexto.

---

MOS-CORE consulta contexto.

---

# 10. COMMAND INTEGRATION

MOS-CORE utiliza:

```text
MOS-COMMAND-ROUTER
```

---

Para resolver:

```text
//audit

//strategy

//content-plan
```

---

MOS-CORE no interpreta comandos.

---

MOS-CORE recibe comandos resueltos.

---

# 11. INPUT INTEGRATION

MOS-CORE utiliza:

```text
MOS-INPUT-SYSTEM
```

---

Para:

* identificar archivos
* clasificar entradas
* validar formatos

---

# 12. OUTPUT INTEGRATION

MOS-CORE utiliza:

```text
MOS-OUTPUT-SYSTEM
```

---

Para:

* construir entregables
* estructurar resultados
* preparar exportaciones

---

# 13. CIP INTEGRATION

Antes de entregar una respuesta:

MOS-CORE debe enviar el resultado a:

```text
CIP
```

---

Capas:

```text
HCEP

↓

CRL

↓

HRR
```

---

Objetivo:

Optimizar experiencia cognitiva.

---

# 14. FAILURE MANAGEMENT

MOS-CORE debe detectar:

---

Dependencias faltantes.

---

Contexto insuficiente.

---

Entradas inválidas.

---

Workflows incompletos.

---

Protocolos inexistentes.

---

# 15. EXECUTION STATES

Estados posibles:

---

Idle

---

Waiting Input

---

Executing

---

Validating

---

Building Output

---

Completed

---

Failed

---

# 16. SUCCESS CRITERIA

MOS-CORE se considera exitoso cuando:

---

Activa protocolos correctos.

---

Respeta dependencias.

---

Mantiene consistencia.

---

Entrega resultados completos.

---

No invade responsabilidades de otros componentes.

---

# 17. PRINCIPLE

MOS-CORE no piensa.

MOS-CORE coordina.

Los protocolos piensan.

---

END OF COMPONENT
